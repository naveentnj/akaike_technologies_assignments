# Internship Assignment for NLP

## Creation of MCQs with Multiple Correct Answer using generative text models
1. Update the python code in script.py
2. The Dataset folder consists of PDFs of Social Science textbook
3. You are required to use the PDFs and extract the context from it, use the extracted text to pass through the get_mca_questions and generate MCA questions
4. Update the Report.txt file with necessary project explanations
