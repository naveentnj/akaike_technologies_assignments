## Import all the dependent libraries
import os
from PyPDF2 import PdfReader
import spacy
import  random

def generate_mcq_with_multiple_correct_choices(question, correct_answers, other_options, num_options=4):
        choices = correct_answers + other_options
        random.shuffle(choices)

        mcq = {
            "question": question,
            "choices": choices,
            "correct_answers": correct_answers
        }

        return mcq
def generate_variety_question(input_document):
        sentence = random.choice(list(input_document.sents))
        blank_word = random.choice([token for token in sentence if not token.is_punct])

        question_text = sentence.text.replace(blank_word.text, "______")
        correct_answers = [blank_word.text]

        other_options = [token.text for token in input_document if token.is_alpha and token.text != correct_answers[0]]
        num_correct_options = random.randint(1, 3)  
        correct_answers.extend(random.sample(other_options, num_correct_options))

        num_other_options = min(4 - num_correct_options, len(other_options))
        other_options = random.sample(other_options, num_other_options)

        mcq = generate_mcq_with_multiple_correct_choices(question_text, correct_answers, other_options)
        return mcq

# Loaded English Language Spacy Model
language_model = spacy.load("en_core_web_trf")

def get_mca_questions(context: str):
    input_document = language_model(context)
    num_questions = 4
    questions = [generate_variety_question(input_document) for _ in range(num_questions)]

    mca_questions = []
    for question_index, question in enumerate(questions, start=1):
        question_str = f"Q{question_index}: {question['question']}\n"
        options_str = ""
        for option_index, option in enumerate(question['choices']):
            options_str += f"{option_index+1}. {option}\n"

        correct_options_formatted = " & ".join([f"({chr(97+question['choices'].index(ans))})" for ans in question['correct_answers']])
        correct_options_str = f"Correct Choices: {correct_options_formatted}"

        mca_question = f"{question_str}{options_str}{correct_options_str}\n"
        mca_questions.append(mca_question)

    return mca_questions


def get_pdf_text(pdf_docs):
   text = ""
   pdf_reader = PdfReader(pdf_docs)
   for page in pdf_reader.pages:
      text += page.extract_text()
   return text


# Set the path to the dataset folder
dataset_folder = r'test_cv\Dataset'
pdf_path = r"internship-assignment-nlp\Dataset"
pdf_docs =  ["chapter-2.pdf", "chapter-3.pdf", "chapter-4.pdf"]
# Process each folder in the dataset
for pdf_file in pdf_docs:
    pdf_file_path = os.path.join(pdf_path, pdf_file)

    # Check if the file exists
    if os.path.isfile(pdf_file_path):
        context = get_pdf_text(pdf_file_path)
        
        # Assuming get_mca_questions takes the context and returns a list of questions
        mca_questions = get_mca_questions(context)
        
        for question in mca_questions:
            print(question)

