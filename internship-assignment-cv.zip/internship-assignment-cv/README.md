# Internship Assignment for Computer Vision
## Steps
1. Update the python code in script.py
2. The Dataset folder consists of 
	a. Sample Images
	b. Inference Images
3. You are required to use the the Fully Annotated Images and Original Images to come up with Partially Annotated Image
4. Update the Report.txt file with necessary project explanations
