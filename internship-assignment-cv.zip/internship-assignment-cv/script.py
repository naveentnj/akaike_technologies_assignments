import os
import cv2
import numpy as np

def get_segmentation_annotations(segmentation_mask):
    hw = segmentation_mask.shape[:2]
    segmentation_mask = segmentation_mask.reshape(hw)
    polygons = []
    
    # Use cv2.RETR_EXTERNAL mode to get only the outermost contours
    contours, _ = cv2.findContours(segmentation_mask.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    
    for contour in contours:
        # Get the segmentation type from the mask value at any point inside the contour
        segtype = segmentation_mask[tuple(contour[0][0])]
        
        # Filter out contours that are too small or too large
        area = cv2.contourArea(contour)
        if area < 100 or area > 10000:
            continue
            
        polygons.append((contour, segtype))
    
    return polygons

def get_output_image(original_image_path: str, fully_annotated_image_path: str,
                     partially_annotated_image_path: str):
    """
    Generates a partially de-annotated image based on the original and fully annotated images.

    Args:
        original_image_path (str): Path to the original image.
        fully_annotated_image_path (str): Path to the fully annotated image.
        partially_annotated_image_path (str): Path to save the partially annotated resultant image.

    Returns:
        None
    """

    # Load the images
    original_image = cv2.imread(original_image_path)
    fully_annotated_image = cv2.imread(fully_annotated_image_path)

    # Find contours in the fully annotated image using segmentation technique
    contours, _ = cv2.findContours(cv2.cvtColor(fully_annotated_image, cv2.COLOR_BGR2GRAY), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    
    # Iterate through contours and remove larger annotations overlapping with smaller ones
    for contour in contours:
        x, y, w, h = cv2.boundingRect(contour)
        if w * h < 10000:  # Adjust the threshold based on your criteria for small animal objects
            cv2.drawContours(original_image, [contour], -1, (0, 0, 0), thickness=cv2.FILLED)

    # Save the partially annotated image
    cv2.imwrite(partially_annotated_image_path, original_image)


# Set the path to the dataset folder
dataset_folder = r'test_cv\Dataset'

# Process each folder in the dataset
for folder_name in os.listdir(dataset_folder):
    folder_path = os.path.join(dataset_folder, folder_name)

    # Check if the folder contains the required images
    original_image_path = os.path.join(folder_path, 'original_image.jpg')
    fully_annotated_image_path = os.path.join(folder_path, 'fully_annotated_image.jpg')
    partially_annotated_image_path = os.path.join(folder_path, 'partially_annotated_image_segmented.jpg')

    if os.path.isfile(original_image_path) and os.path.isfile(fully_annotated_image_path):
        # Check if the partially annotated image is available
        if os.path.isfile(partially_annotated_image_path):
            # Generate the partially annotated image
            get_output_image(original_image_path, fully_annotated_image_path, partially_annotated_image_path)
        else:
            # Generate the partially annotated image without the given input
            partially_annotated_image_path = os.path.join(folder_path, 'partially_annotated_image_segmented_generated.jpg')
            get_output_image(original_image_path, fully_annotated_image_path, partially_annotated_image_path)
